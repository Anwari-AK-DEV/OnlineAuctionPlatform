import React from "react";
import PagePlaceholder from "../components/PagePlaceholder";

function Login() {
  return (
    <PagePlaceholder
      title="Login"
      description="The login form will live here."
    />
  );
}

export default Login;
