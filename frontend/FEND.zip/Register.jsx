import React from "react";
import PagePlaceholder from "../components/PagePlaceholder";

function Register() {
  return (
    <PagePlaceholder
      title="Register"
      description="The account registration form will live here."
    />
  );
}

export default Register;
