import React from "react";
import PagePlaceholder from "../components/PagePlaceholder";

function Home() {
  return (
    <PagePlaceholder
      title="Home"
      description="Welcome banner, featured auctions, and highlights will live here."
    />
  );
}

export default Home;
