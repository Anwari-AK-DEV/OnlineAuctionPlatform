import React, { useState } from "react";
import { NavLink, Link } from "react-router-dom";
import "./Navbar.css";

const NAV_LINKS = [
  { to: "/", label: "Home", end: true },
  { to: "/auctions", label: "Auctions" },
  { to: "/categories", label: "Categories" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

const AUTH_LINKS = [
  { to: "/login", label: "Login" },
  { to: "/register", label: "Register" },
];

function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const closeMenu = () => setIsMenuOpen(false);

  const navLinkClass = ({ isActive }) =>
    isActive ? "navbar__link navbar__link--active" : "navbar__link";

  return (
    <header className="navbar">
      <div className="navbar__container">
        {/* Logo / Platform name */}
        <Link to="/" className="navbar__logo" onClick={closeMenu}>
          <span className="navbar__logo-icon" aria-hidden="true">
            🔨
          </span>
          <span className="navbar__logo-text">AuctionHub</span>
        </Link>

        {/* Desktop nav */}
        <nav className="navbar__nav" aria-label="Primary">
          <ul className="navbar__links">
            {NAV_LINKS.map((link) => (
              <li key={link.to}>
                <NavLink
                  to={link.to}
                  end={link.end}
                  className={navLinkClass}
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>

          <div className="navbar__auth">
            <NavLink to="/login" className="navbar__btn navbar__btn--ghost">
              Login
            </NavLink>
            <NavLink to="/register" className="navbar__btn navbar__btn--solid">
              Register
            </NavLink>
          </div>
        </nav>

        {/* Mobile menu toggle */}
        <button
          className={`navbar__toggle ${isMenuOpen ? "is-open" : ""}`}
          aria-label="Toggle navigation menu"
          aria-expanded={isMenuOpen}
          onClick={() => setIsMenuOpen((prev) => !prev)}
        >
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>

      {/* Mobile nav */}
      <nav
        className={`navbar__mobile ${isMenuOpen ? "navbar__mobile--open" : ""}`}
        aria-label="Mobile"
      >
        <ul className="navbar__mobile-links">
          {NAV_LINKS.map((link) => (
            <li key={link.to}>
              <NavLink
                to={link.to}
                end={link.end}
                className={navLinkClass}
                onClick={closeMenu}
              >
                {link.label}
              </NavLink>
            </li>
          ))}
          {AUTH_LINKS.map((link) => (
            <li key={link.to}>
              <NavLink
                to={link.to}
                className={navLinkClass}
                onClick={closeMenu}
              >
                {link.label}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
}

export default Navbar;
