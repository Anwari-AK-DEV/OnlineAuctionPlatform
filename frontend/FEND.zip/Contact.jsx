import React from "react";
import PagePlaceholder from "../components/PagePlaceholder";

function Contact() {
  return (
    <PagePlaceholder
      title="Contact"
      description="A contact form and support details will live here."
    />
  );
}

export default Contact;
