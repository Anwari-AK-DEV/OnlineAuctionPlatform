import React from "react";
import PagePlaceholder from "../components/PagePlaceholder";

function Auctions() {
  return (
    <PagePlaceholder
      title="Auctions"
      description="A browsable, filterable list of live and upcoming auctions will live here."
    />
  );
}

export default Auctions;
