import React from "react";
import PagePlaceholder from "../components/PagePlaceholder";

function Categories() {
  return (
    <PagePlaceholder
      title="Categories"
      description="Category browsing (Electronics, Art, Vehicles, etc.) will live here."
    />
  );
}

export default Categories;
