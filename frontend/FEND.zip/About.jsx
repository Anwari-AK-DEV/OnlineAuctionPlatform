import React from "react";
import PagePlaceholder from "../components/PagePlaceholder";

function About() {
  return (
    <PagePlaceholder
      title="About"
      description="Information about the platform and how auctions work will live here."
    />
  );
}

export default About;
